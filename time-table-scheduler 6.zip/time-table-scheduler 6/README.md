Prerequisite:
1. Java should be installed on system.
2. Maven should be installed on system.

Steps to run App:

1. Run the Application.
    * Either Run the app in IDE.
    * OR run `mvn spring-boot:run` in terminal inside project folder. (Maven should be installed on system)

2. Open link `localhost:8080` on browser.