package com.amity.timetablescheduler.model;

import java.util.List;

public class StudentGroup {
  private int id;
  private String name;
  private List<String> subjects;
  private List<Integer> teacherIds;
  private List<Integer> hours;

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public List<String> getSubjects() {
    return subjects;
  }

  public void setSubjects(List<String> subjects) {
    this.subjects = subjects;
  }

  public List<Integer> getTeacherIds() {
    return teacherIds;
  }

  public void setTeacherIds(List<Integer> teacherIds) {
    this.teacherIds = teacherIds;
  }

  public List<Integer> getHours() {
    return hours;
  }

  public void setHours(List<Integer> hours) {
    this.hours = hours;
  }
}
