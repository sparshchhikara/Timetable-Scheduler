package com.amity.timetablescheduler.model;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Chromosome {
  private List<Gene> genes;
  private int hoursPerWeek;
  private int noOfStudentGroups;
  private double fitness;
  private List<Slot> slots;

  public Chromosome() {}

  public Chromosome(TimeTableSlots timeTableSlots) {
    genes = new ArrayList<>();
    this.hoursPerWeek = timeTableSlots.getHoursPerWeek();
    this.noOfStudentGroups = timeTableSlots.getNoOfStudentGroups();
    this.slots = timeTableSlots.getSlots();

    for (int i = 0; i < noOfStudentGroups; i++) {
      genes.add(new Gene(i, hoursPerWeek));
    }
  }

  public List<Gene> getGenes() {
    return genes;
  }

  /**
   * We calculate no. of instances when same teacher is teaching >1 class at the same time.
   *
   * The less it is the more fit our chromosome (TimeTable) is.
   *
   * Most fit candidate doesn't have such invalid instances.
   */
  public double calculateFitness() {
    int clashes = 0;

    for (int slotInTimeTable = 0; slotInTimeTable < hoursPerWeek; slotInTimeTable++) {

      Set<Integer> alreadyAssignedTeachers = new HashSet<>();

      for (int studentGroupIndex = 0; studentGroupIndex < noOfStudentGroups; studentGroupIndex++) {

        Slot slot = slots.get(
            genes.get(studentGroupIndex).getSlotNumbers().get(slotInTimeTable)
        );

        if (slot != null && !alreadyAssignedTeachers.add(slot.getTeacherId())) {
            clashes++;
        }
      }
    }

    fitness = 1 - (clashes / ((noOfStudentGroups - 1.0) * hoursPerWeek));
    return fitness;
  }

  public List<Slot> getSlots() {
    return slots;
  }

  public double getFitness() {
    return fitness;
  }

  public int getHoursPerWeek() {
    return hoursPerWeek;
  }

  public int getNoOfStudentGroups() {
    return noOfStudentGroups;
  }
}
