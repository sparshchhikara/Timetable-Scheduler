package com.amity.timetablescheduler.model;

public class Slot {
  private StudentGroup studentGroup;
  private int teacherId;
  private String teacherName;
  public String subject;

  public Slot() {}

  public Slot(StudentGroup studentGroup, int teacherId, String subject) {
    this.studentGroup = studentGroup;
    this.teacherId = teacherId;
    this.subject = subject;
  }

  public int getTeacherId() {
    return teacherId;
  }

  public StudentGroup getStudentGroup() {
    return studentGroup;
  }

  public void setStudentGroup(StudentGroup studentGroup) {
    this.studentGroup = studentGroup;
  }

  public void setTeacherId(int teacherId) {
    this.teacherId = teacherId;
  }

  public String getSubject() {
    return subject;
  }

  public void setSubject(String subject) {
    this.subject = subject;
  }

  public String getTeacherName() {
    return teacherName;
  }

  public void setTeacherName(String teacherName) {
    this.teacherName = teacherName;
  }
}
