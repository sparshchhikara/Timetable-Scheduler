package com.amity.timetablescheduler.model;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class InputData {
  private List<StudentGroup> studentGroups;
  private List<Teacher> teachers;
  private final double crossOverRate = 1.0;
  private final double mutationRate = 0.1;
  private int hoursPerDay;
  private int daysPerWeek;

  public List<StudentGroup> getStudentGroups() {
    return studentGroups;
  }

  // assigning a teacher for each subject for every studentGroup
  public void assignTeacher() {

    // first assign ids to all teachers
    for (int i = 0; i < teachers.size(); i++) {
      teachers.get(i).setId(i);
    }

    // looping through every studentGroup
    for (StudentGroup studentGroup : studentGroups) {
      assignTeacher(studentGroup);
    }
  }

  // Assign teachers that should be assigned a studentGroup
  private void assignTeacher(StudentGroup studentGroup) {

    List<Integer> teacherIds = new ArrayList<>();

    // looping through every subject of a student group
    for (String subject: studentGroup.getSubjects()) {

      Teacher minimallyAssignedTeacher = teachers.stream()
          .filter(teacher -> teacher.getSubject().equalsIgnoreCase(subject))
          .min(Comparator.comparing(Teacher::getLecturesAssigned))
           .orElseThrow(() -> new RuntimeException("Error while getting minimally assigned teacher."));

      minimallyAssignedTeacher.setLecturesAssigned(minimallyAssignedTeacher.getLecturesAssigned() + 1);

      teacherIds.add(minimallyAssignedTeacher.getId());
    }

    studentGroup.setTeacherIds(teacherIds);
  }

  public List<Teacher> getTeachers() {
    return teachers;
  }

  public double getCrossOverRate() {
    return crossOverRate;
  }

  public int getHoursPerWeek() {
    return hoursPerDay * daysPerWeek;
  }

  public int getHoursPerDay() {
    return hoursPerDay;
  }

  public int getDaysPerWeek() {
    return daysPerWeek;
  }
}
