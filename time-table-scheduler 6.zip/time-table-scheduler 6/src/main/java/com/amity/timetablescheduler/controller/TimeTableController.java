package com.amity.timetablescheduler.controller;

import com.amity.timetablescheduler.model.Chromosome;
import com.amity.timetablescheduler.model.InputData;
import com.amity.timetablescheduler.service.LoginService;
import com.amity.timetablescheduler.service.SchedulerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.view.RedirectView;

import javax.naming.AuthenticationException;

@RestController
public class TimeTableController {

  @Autowired
  private SchedulerService schedulerService;

  @Autowired
  private LoginService loginService;

  @PostMapping("timeTable")
  public Chromosome getTimeTable(@RequestBody InputData inputData) throws Exception {
    //after getting all input, teachers are assigned to each subject
    inputData.assignTeacher();

    return schedulerService.generateResults(inputData);
  }

  @PostMapping("login")
  public RedirectView login(@RequestParam String userName,
                            @RequestParam String password)
      throws AuthenticationException {

    loginService.login(userName, password);
    return new RedirectView("/index.html");
  }
}
