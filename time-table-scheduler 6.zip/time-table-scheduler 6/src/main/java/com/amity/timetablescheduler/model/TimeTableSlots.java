package com.amity.timetablescheduler.model;

import java.util.ArrayList;
import java.util.List;

public class TimeTableSlots {
  private List<Slot> slots;
  private int hoursPerWeek;
  private int noOfStudentGroups;

  public TimeTableSlots() {}

  /**
   * Create all timeSlots (no.of.student-groups * hoursPerWeek) of a TimeTable
   * and for every student-group add hoursPerWeek slots by:
   *
   * 1. Adding Slots for all subjects one by one like adding required x slots for subA,
   *    then y(given) slots of subB etc. etc.
   *
   * 2. for remaining slots add blanks.
   */
  public TimeTableSlots(int hoursPerWeek, List<StudentGroup> studentGroups) {
    this.hoursPerWeek = hoursPerWeek;
    this.noOfStudentGroups = studentGroups.size();

    // creating as many slots as the no of blocks in overall timetable
    slots = new ArrayList<>();

    for (StudentGroup studentGroup : studentGroups) {
      int subjectNo = 0;
      int hourCount = 1;

      // for every slot in a week for a student group
      for (int j = 0; j < hoursPerWeek; j++) {

        // if all subjects have been assigned required hours we give
        // free periods
        if (subjectNo >= studentGroup.getSubjects().size()) {
          slots.add(null);
        }

        // if not we create new slots
        else {

          Slot newSlot = new Slot(studentGroup, studentGroup.getTeacherIds().get(subjectNo),
              studentGroup.getSubjects().get(subjectNo));

          slots.add(newSlot);

          // suppose java has to be taught for 5 hours then we make 5
          // slots for java, we keep track through hourCount
          if (hourCount < studentGroup.getHours().get(subjectNo)) {
            hourCount++;
          } else {
            hourCount = 1;
            subjectNo++;
          }

        }
      }
    }

  }

  public List<Slot> getSlots() {
    return slots;
  }

  public int getHoursPerWeek() {
    return hoursPerWeek;
  }

  public int getNoOfStudentGroups() {
    return noOfStudentGroups;
  }
}
