package com.amity.timetablescheduler.utils;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.util.List;

public class CommonUtils {
  private static ObjectMapper mapper = new ObjectMapper();

  public static <T> T deepClone(T object, Class<T> type) throws IOException {
    String serializedObject = mapper.writeValueAsString(object);
    return mapper.readValue(serializedObject, type);
  }

  public static <T> void swap(List<T> firstCollection, List<T> secondCollection,
                              int index) {
    T temp = firstCollection.get(index);
    firstCollection.set(index, secondCollection.get(index));
    secondCollection.set(index, temp);
  }
}
