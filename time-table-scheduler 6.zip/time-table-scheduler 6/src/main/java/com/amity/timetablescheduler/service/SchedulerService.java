package com.amity.timetablescheduler.service;

import com.amity.timetablescheduler.model.Chromosome;
import com.amity.timetablescheduler.model.Gene;
import com.amity.timetablescheduler.model.InputData;
import com.amity.timetablescheduler.model.Teacher;
import com.amity.timetablescheduler.model.TimeTableSlots;
import com.amity.timetablescheduler.utils.CommonUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.stream.Collectors;

/*
 * Time Table scheduling is an np-hard problem which can best be solved
 * using Genetic Algorithms (of Artificial Intelligence).
 * Concepts used here are Permutation encoding, elitism, roulette wheel selection,
 * single pt crossover,swap mutation
 */
@Service
public class SchedulerService {
  private List<Chromosome> currentGeneration;
  private double currentGenerationFitness;
  private final int populationSize = 1000;
  private final int maxGenerations = 100;

  public Chromosome generateResults(InputData inputData) throws Exception {
    initialisePopulation(inputData);

    // check if we luckily already got the solution
    if (currentGeneration.get(0).getFitness() == 1) {
      return currentGeneration.get(0);
    }

    Chromosome bestValue = getFittestOffspringFromFutureGenerations();

    if (bestValue != null) {
      addTeacherNames(bestValue, inputData.getTeachers());
    }

    return bestValue;
  }

  // create population of first generation
  private void initialisePopulation(InputData inputData) {
    currentGenerationFitness = 0;
    currentGeneration = new ArrayList<>(populationSize);
    TimeTableSlots timeTableSlots =
        new TimeTableSlots(inputData.getHoursPerWeek(), inputData.getStudentGroups());

    for (int i = 0; i < populationSize; i++) {
      Chromosome c = new Chromosome(timeTableSlots);
      currentGeneration.add(c);
      currentGenerationFitness += c.calculateFitness();
    }
    currentGeneration.sort(Comparator.comparing(Chromosome::calculateFitness).reversed()); // descending order
  }

  //Creating new Generations using crossovers and mutations and return best fit Chromosome
  private Chromosome getFittestOffspringFromFutureGenerations() throws Exception {

    Chromosome offspring = null;

    //looping max no of generations times or until suitable chromosome found
    for (int generationCount = 0; generationCount < maxGenerations; ++generationCount) {

      List<Chromosome> nextGeneration = new ArrayList<>();
      int currentIndex = 0;

      //first 1/10 chromosomes added as it is- Elitism
      while (currentIndex < populationSize / 10) {
        nextGeneration.add(CommonUtils.deepClone(currentGeneration.get(currentIndex), Chromosome.class));
        currentIndex++;
      }

      //adding other members after performing crossover and mutation
      while (currentIndex < populationSize) {

        Chromosome father = selectParentUsingRoulette();
        Chromosome mother = selectParentUsingRoulette();

        offspring = crossoverGenes(father, mother);

        applyMutation(offspring);

        // we found what we were looking for
        if (offspring.calculateFitness() == 1) {
          return offspring;
        }

        nextGeneration.add(offspring);
        currentIndex++;
      }

      //if chromosome with required fitness not found in this generation then carry on to next generation
      nextGeneration.sort(Comparator.comparing(Chromosome::calculateFitness).reversed()); // descending order sort
      currentGeneration = nextGeneration;
    }

    // we didn't find any possible chromosome that is completely fit
    return null;
  }

  //selecting a parent (using Roulette Wheel Selection) from the best 10% chromosomes
  private Chromosome selectParentUsingRoulette() throws Exception {
    currentGenerationFitness /= 10;

    // select random number between 0 and 10% of total fitness of current Generation
    double randomFitnessSum = new Random().nextDouble() * (currentGenerationFitness);
    double currentFitnessSum = 0;
    int i = 0;

    while (currentFitnessSum <= randomFitnessSum) {
      currentFitnessSum += currentGeneration.get(i++).calculateFitness();
    }
    return CommonUtils.deepClone(currentGeneration.get(--i), Chromosome.class);
  }

  //Two point crossover: Swap genes at random index and return most fit candidate
  private Chromosome crossoverGenes(Chromosome father, Chromosome mother) {
    int randomGeneIndex = new Random().nextInt(father.getGenes().size());

    CommonUtils.swap(father.getGenes(), mother.getGenes(), randomGeneIndex);

    if (father.calculateFitness() > mother.calculateFitness()) {
      return father;
    } else {
      return mother;
    }
  }

  /**
   * Pick random Gene from Chromosome
   * and mutate it until whole chromosome's fitness
   * becomes at least it's previous value
   */
  private void applyMutation(Chromosome chromosome) {
    double newFitness = 0, oldFitness = chromosome.calculateFitness();
    int randomGeneIndex = new Random().nextInt(chromosome.getGenes().size());
    int slotCountPerGene = chromosome.getSlots().size() / chromosome.getGenes().size();

    int i = 0;
    while (newFitness < oldFitness) {
      chromosome.getGenes().set(randomGeneIndex,
          new Gene(randomGeneIndex, slotCountPerGene));

      newFitness = chromosome.calculateFitness();

      i++;
      if (i >= 500000) break;
    }
  }

  private void addTeacherNames(Chromosome bestValue, List<Teacher> teachers) {
    Map<Integer, String> teacherNames = teachers.stream()
        .collect(Collectors.toMap(Teacher::getId, Teacher::getName));

    bestValue.getSlots()
        .stream()
        .filter(Objects::nonNull)
        .forEach(slot -> slot.setTeacherName(teacherNames.get(slot.getTeacherId() + 1)));
  }
}