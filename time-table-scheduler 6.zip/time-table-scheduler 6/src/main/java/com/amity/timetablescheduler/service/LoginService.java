package com.amity.timetablescheduler.service;

import com.amity.timetablescheduler.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import javax.naming.AuthenticationException;
import java.util.List;

@Service
public class LoginService {

  @Autowired
  private JdbcTemplate jdbcTemplate;

  public void login(String userName, String password) throws AuthenticationException {
    List<User> users =
      jdbcTemplate.query("SELECT user_name, password FROM users WHERE user_name = ? AND password = ?",
          new Object[] {userName, password},
        (resultSet, index) -> new User(resultSet.getString("user_name"), resultSet.getString("password")));

    if (users.isEmpty()) {
      throw new AuthenticationException("User or Password is not correct");
    }
  }
}
