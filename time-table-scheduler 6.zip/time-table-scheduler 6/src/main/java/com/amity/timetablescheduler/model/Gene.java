package com.amity.timetablescheduler.model;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Gene {
  private List<Integer> slotNumbers;

  public Gene() {}

  /**
   * Create and save slots
   * from previousGenes to (previousGenes + slotCountPerGene)
   * in random order
   *
   * where previousGenes = (geneNumber * slotCountPerGene)
   */
  public Gene(int geneNumber, int slotCountPerGene) {
    slotNumbers = IntStream.range(0, slotCountPerGene)
        .map(num -> num + (geneNumber * slotCountPerGene))
        .boxed().collect(Collectors.toList());

    Collections.shuffle(slotNumbers);
  }

  public List<Integer> getSlotNumbers() {
    return slotNumbers;
  }
}
