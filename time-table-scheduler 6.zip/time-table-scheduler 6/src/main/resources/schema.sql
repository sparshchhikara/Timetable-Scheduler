DROP TABLE USERS IF EXISTS;
CREATE TABLE USERS (
    user_name varchar(30) NOT NULL,
    password varchar(30) NOT NULL
);