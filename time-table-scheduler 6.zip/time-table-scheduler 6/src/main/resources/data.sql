INSERT INTO USERS
VALUES('admin', 'admin');